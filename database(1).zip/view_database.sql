CREATE VIEW custom_added_users AS SELECT * FROM users WHERE added_by!='system' ORDER BY registered DESC LIMIT 5, 30;
	SELECT * FROM custom_added_users;
CREATE VIEW users_by_vips_plus_library AS SELECT * FROM users, vips, vips_library WHERE users.id=vips_library.user_id_fk AND vips.id=vips_library.vip_id_fk;
	SELECT * FROM users_by_vips_plus_library;
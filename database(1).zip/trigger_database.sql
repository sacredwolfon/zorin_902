DELIMITER ==
CREATE TRIGGER `drop_user_data`
    BEFORE DELETE ON `users` FOR EACH ROW
    BEGIN
        DELETE FROM vips_library WHERE OLD.id=vips_library.user_id_fk;
        DELETE FROM bannes WHERE OLD.id=bannes.user_id_fk;
        DELETE FROM bot WHERE OLD.id=bot.owner_id;
        DELETE FROM admin WHERE OLD.id=config.admin_id;
        DELETE FROM pool_requests WHERE OLD.id=pool_requests.user_id_fk;
        DELETE FROM transactions WHERE OLD.id=transactions.user_id_fk;
    END==
DELIMITER ;
--DELETE FROM users WHERE id=2;
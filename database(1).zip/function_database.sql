DELIMITER ==

CREATE FUNCTION leave_a_comment (user_id INT, msg VARCHAR(100))
    RETURNS VARCHAR(20) DETERMINISTIC
    BEGIN
        IF ((SELECT comment FROM users WHERE id = user_id) = '') THEN UPDATE users SET comment = msg, added_by='custom' WHERE id=user_id;
        ELSE RETURN 'comment exist';
        END IF;
        RETURN 'success';
END==

DELIMITER ;

SELECT leave_a_comment(1, 'admin account');
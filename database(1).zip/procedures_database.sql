DELIMITER ==

CREATE PROCEDURE get_vips_library_by_users()
BEGIN
	DECLARE i INT DEFAULT (SELECT MAX(id) FROM users);

	WHILE i > 0 DO
    	SELECT users.id, users.username, (SELECT name FROM vips WHERE id = vips_library.vip_id_fk) AS 'vip_name', vips_library.sub_start, vips_library.sub_finish FROM users INNER JOIN vips_library ON users.id = vips_library.user_id_fk WHERE users.id = i;
    	SET i = i - 1;
	END WHILE;
END==

DELIMITER ;

CALL get_vips_library_by_users();